package edu.pucp.gtics.lab5_gtics_20211;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5GTics20211ApplicationTests {

    @Test
    void contextLoads() {
    }

}
