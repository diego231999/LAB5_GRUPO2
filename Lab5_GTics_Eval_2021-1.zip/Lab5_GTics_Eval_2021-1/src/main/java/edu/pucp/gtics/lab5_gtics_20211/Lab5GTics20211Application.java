package edu.pucp.gtics.lab5_gtics_20211;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab5GTics20211Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab5GTics20211Application.class, args);
    }

}
