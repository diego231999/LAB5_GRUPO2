package edu.pucp.gtics.lab5_gtics_20211.entity;

public interface JuegosUserDto {

     /** Completar */


}
